﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using XPRESS.Common;

public partial class Sales_SaleUI_FrmSalesInvoiceDgv : System.Web.UI.Page
{  

    DataTable dtInvoicesList = new DataTable();
    int? culture = 0;
    UserProfile userProfile;
    global::MyContext context;
    public Sales_SaleUI_FrmSalesInvoiceDgv()
    {        
        culture = 0;        
        if (!string.IsNullOrWhiteSpace(HttpContext.Current.Request.QueryString["PreferedCulture"]))
        {
            culture = HttpContext.Current.Request.QueryString["PreferedCulture"].ToInt();
        }
        else
        {
            if (User.Identity.IsAuthenticated && User.Identity.Name != string.Empty)
            {
                context = new global::MyContext(Membership.GetUser(User.Identity.Name));
                userProfile = context.UserProfile;
                culture = (int)context.UserProfile.UserCulture;
            }
            else
            {
                culture = 0;
            }
        }

        //UICulture = culture == 0 ? "ar-eg" : "en-us";
        //this.Culture = culture == 0 ? "ar-eg" : "en-us";
        Thread.CurrentThread.CurrentCulture = Thread.CurrentThread.CurrentUICulture = new CultureInfo(culture == 0 ? "ar-eg" : "en-us", false);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //Response.Cache.SetNoStore();
        if (!Page.IsPostBack)
        {            
            /*DgvSelectDoc.Columns[8].Visible = context.PageData.IsViewDoc;
            DgvSelectDoc.Columns[9].Visible = context.PageData.IsPrint;*/
            DgvSelectDoc.PageIndex = 0;
            this.FillSaleInvoicesList(0);
        }
        //Response.Cache.SetNoStore();
    }

    private void FillSaleInvoicesList(int PageIndex)
    {
        int? Currency_ID = Request.QueryString["Currency"].ToNullableInt(), CollectType = -1, rep_ID = null, typePayment_ID = -2;
        byte? DocStatus_ID = string.IsNullOrWhiteSpace(Request.QueryString["Status"]) ? (byte?)null : Request.QueryString["Status"].ToByte();
        byte? EntryType = 2;
        bool? HasInvoice = null;
        int? created_by = null;
        if (this.userProfile == null || userProfile.HasPermissionShow == false)
            created_by = null;
        else created_by = this.userProfile.Contact_ID;

        decimal? txtGrossTotal = 0;
        string txtSerial = string.Empty, txtDateFromSrch = string.Empty, txtDateToSrch = string.Empty, txtUserRefNo = string.Empty,
                txtCustomerName = string.Empty, txtCustomerMobile = string.Empty, txtNotess = string.Empty;
        var dc = new XpressDataContext();
        /*dtInvoicesList = dc.usp_InvoiceRep_Select(Request.QueryString["Branch"].ToNullableInt(), Currency_ID, Request.QueryString["SearchText"],
            Request.QueryString["Contact_ID"].ToNullableInt(), Request.QueryString["DateFrom"].ToDate(), Request.QueryString["DateTo"].ToDate(),
            Request.QueryString["UserRefNo"], DocStatus_ID, this.culture.ToByte(), HasInvoice, EntryType, CollectType,created_by, rep_ID,
            txtCustomerName, txtCustomerMobile, txtNotess, txtGrossTotal, typePayment_ID)
            .OrderByDescending(r => r.OperationDate)
            .CopyToDataTable();*/

        dtInvoicesList = dc.usp_InvoiceRep_SelectPaging(PageIndex,DgvSelectDoc.PageSize, Request.QueryString["Branch"].ToNullableInt(), Currency_ID, Request.QueryString["SearchText"],
            Request.QueryString["Contact_ID"].ToNullableInt(), Request.QueryString["DateFrom"].ToDate(), Request.QueryString["DateTo"].ToDate(),
            Request.QueryString["UserRefNo"], DocStatus_ID, this.culture.ToByte(), HasInvoice, EntryType, CollectType, created_by, rep_ID,
            txtCustomerName, txtCustomerMobile, txtNotess, txtGrossTotal, typePayment_ID)
            .OrderByDescending(r => r.OperationDate)
            .CopyToDataTable();
        if (dtInvoicesList != null && dtInvoicesList.Rows.Count > 0 && dtInvoicesList.Rows[0]["TotalRows"] != DBNull.Value)
            DgvSelectDoc.VirtualItemCount = dtInvoicesList.Rows[0]["TotalRows"].ToInt();
        DgvSelectDoc.DataSource = dtInvoicesList;
        DgvSelectDoc.DataBind();        
    }
    
    protected void DgvSelectDoc_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            DgvSelectDoc.PageIndex = e.NewPageIndex;
            this.FillSaleInvoicesList(e.NewPageIndex);            
        }
        catch (Exception ex)
        {
            Logger.LogError(Resources.UserInfoMessages.OperationFailed, ex);
        }
    }

    protected void DgvSelectDoc_PageIndexChanged(object sender, EventArgs e)
    {
        
    }
}