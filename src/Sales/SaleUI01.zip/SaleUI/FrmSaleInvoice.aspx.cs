﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using XPRESS.Common;

public partial class Sales_SaleUI_FrmSaleInvoice : UICulturePage
{
    XpressDataContext dc = new XpressDataContext();
    public int TypeTax
    {
        get
        {
            if (Session["TypeTax_Invoice" + this.WinID] == null)
            {
                // Session["dtItems_Invoice" + this.WinID] = dc.usp_InvoiceDetails_Select(null).CopyToDataTable();
                Session["TypeTax_Invoice" + this.WinID] = dc.Companies.FirstOrDefault().TypeTax;
            }
            return (int)Session["TypeTax_Invoice" + this.WinID];
        }

        set
        {
            Session["TypeTax_Invoice" + this.WinID] = value;
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            this.LoadControls();
            //InsertCustomers();
        }
    }

    private bool InsertCustomers()
    {

        var company = dc.usp_Company_Select().FirstOrDefault();
        var listCustomer = new List<String>();
        for (int i = 0; i < 50000; i++)
        {
            listCustomer.Add("Customer_" + i.ToString());
        }
        foreach (var row in listCustomer)
        {

            int Contact_ID = dc.usp_Contact_Insert(null, 15, DocSerials.Customer.ToInt(), row, 'C', string.Empty, null);
            int ChartofAccount_ID = dc.usp_ChartOfAccount_Insert(row, row, COA.Customers.ToInt(), true, null, 15, 1, 0, MyContext.FiscalYearStartDate, COA.Capital.ToInt());



            dc.usp_Customers_Insert(Contact_ID, ChartofAccount_ID, null, null, company.UseCustomerCreditLimit, company.CustomerCreditLimit);


        }
        return true;
    }

    protected override void OnInit(EventArgs e)
    {
        this.MyContext = new MyContext();
        base.OnInit(e);
    }

    public string GetCostCenterContextKey()
    {
        return this.MyContext.CurrentCulture.ToByte().ToExpressString() + ",false,";
    }

    public string GetCostomerContextKey()
    {
        string acCustomer = string.Empty;
        if (!MyContext.UserProfile.SalesRepToCustomer.ToBooleanOrDefault())
        {
            acCustomer = ddlCurrency.SelectedValue + ",";
        }
        else acCustomer = ddlCurrency.SelectedValue + "," + MyContext.UserProfile.Area_ID.ToExpressString();
        return acCustomer;
    }

    public string GetCurrentCulture()
    {
        return this.MyContext.CurrentCulture.ToByte().ToExpressString();
    }

    public string GetAcAddressContextKey()
    {
        string acAddress = ContactDetailsTypes.ShipAddress.ToInt().ToExpressString();
        return acAddress;
    }

    public string GeneralAttributesUOM()
    {
        string ContextKey = this.MyContext.CurrentCulture.ToByte().ToExpressString() + "," + GeneralAttributes.UOM.ToInt().ToExpressString();
        return ContextKey;
    }

    private void LoadControls()
    {
        var currency = dc.usp_Currency_Select(false).ToList();
        ddlCurrency.DataSource = currency;
        ddlCurrency.DataTextField = "Name";
        ddlCurrency.DataValueField = "ID";
        ddlCurrency.DataBind();

        NewCustomerCurrency.DataSource = currency;
        NewCustomerCurrency.DataTextField = "Name";
        NewCustomerCurrency.DataValueField = "ID";
        NewCustomerCurrency.DataBind();

        var listSos = dc.SettingPointOs.Where(c => c.IsActive.Value).ToList().Select(c => new PaymentMethodeCls { Name = c.Name, ID = c.ID }).ToList();
        listSos.Add(new PaymentMethodeCls { Name = "اجـل", ID = -1 });
        listSos.Add(new PaymentMethodeCls { Name = "نقدي", ID = 0 });
        ddlPaymentMethod.DataSource = listSos.OrderBy(c => c.ID).ToList();
        ddlPaymentMethod.DataTextField = "Name";
        ddlPaymentMethod.DataValueField = "ID";
        ddlPaymentMethod.DataBind();

        lblCreatedBy.Text = MyContext.UserProfile.EmployeeName;
    }

    public MyContext GetContext()
    {
        var con = new MyContext(System.Web.Security.Membership.GetUser(), PageLinks.Customers, string.Empty);
        return con;
    }
}