﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using XPRESS.Common;

public partial class Sales_SaleUI_FrmSalesInvoiceDgv : UICulturePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            DgvSelectDoc.Columns[8].Visible = this.MyContext.PageData.IsViewDoc;
            DgvSelectDoc.Columns[9].Visible = this.MyContext.PageData.IsPrint;
            this.FillSaleInvoicesList();
        }
    }

    private void FillSaleInvoicesList()
    {
        int? Currency_ID = Request.QueryString["Currency"].ToNullableInt(), CollectType = -1, rep_ID = null, typePayment_ID = -2;
        byte? DocStatus_ID = string.IsNullOrWhiteSpace(Request.QueryString["Status"]) ? (byte?)null : Request.QueryString["Status"].ToByte();
        byte? EntryType = 2;
        bool? HasInvoice = null;

        decimal? txtGrossTotal = 0;
        string txtSerial = string.Empty, txtDateFromSrch = string.Empty, txtDateToSrch = string.Empty, txtUserRefNo = string.Empty,
                txtCustomerName = string.Empty, txtCustomerMobile = string.Empty, txtNotess = string.Empty;
        var dc = new XpressDataContext();
        var dtInvoicesList = dc.usp_InvoiceRep_Select(Request.QueryString["Branch"].ToNullableInt(), Currency_ID, Request.QueryString["SearchText"],
            Request.QueryString["Contact_ID"].ToNullableInt(),Request.QueryString["DateFrom"].ToDate(), Request.QueryString["DateTo"].ToDate(),
            Request.QueryString["UserRefNo"],DocStatus_ID, MyContext.CurrentCulture.ToByte(), HasInvoice, EntryType, CollectType,
            (MyContext.UserProfile.HasPermissionShow == false ? (int?)null : MyContext.UserProfile.Contact_ID), rep_ID,
            txtCustomerName, txtCustomerMobile, txtNotess, txtGrossTotal, typePayment_ID).CopyToDataTable();
        DgvSelectDoc.DataSource = dtInvoicesList;
        DgvSelectDoc.DataBind();
    }

    public string GetCurrentCulture()
    {
        return this.MyContext.CurrentCulture.ToByte().ToExpressString();
    }

    protected override void OnInit(EventArgs e)
    {
        this.MyContext = new MyContext();
        base.OnInit(e);
    }
}